sub degsin{my $x=shift;return sin($pi*$x/180);}
sub degcos{my $x=shift;return cos($pi*$x/180);}
sub degtan{my $x=shift;return tan($pi*$x/180);}
1;
